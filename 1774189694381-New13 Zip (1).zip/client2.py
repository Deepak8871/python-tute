
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

HOST_NAME = "127.0.0.1"
PORT = 9090

s.connect((HOST_NAME, PORT))
print("Connected to server")

while True:
    data = s.recv(1024)
    if not data:
        break
    print("Server:",data.decode("utf-8"))

    message = input("Client: ")
    if message.lower() == "exit":
        break
    s.send(message.encode("utf-8"))

s.close()
