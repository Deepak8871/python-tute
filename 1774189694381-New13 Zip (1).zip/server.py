# Create socket
import socket

from client import HOST_NAME

# Host and Port
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

HOST_NAME = socket.gethostbyname(socket.gethostname())

PORT = 8080

# Bind socket
server.bind((HOST_NAME, PORT))

# Start listening
server.listen(4)
print("Waiting for connection...")
client, address = server.accept()
print("Connection from", address)

while True:
    message = input("Server: ")

    if message.lower() == "exit":
        print("Server closing connection...")
        break

    client.send(message.encode("utf-8"))

    data = client.recv(1024)
    if not data:
        print("Client disconnected")
        break

    print("Client:", data.decode("utf-8"))

client.close()
server.close()
