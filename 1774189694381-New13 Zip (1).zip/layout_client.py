import socket
from tkinter import *

HOST_NAME = "127.0.0.1"
PORT = 9090

def connect_server():
    global s
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((HOST_NAME, PORT))
        listbox.insert(END, "Connected to server")
    except Exception as e:
        listbox.insert(END, f"Connection failed: {e}")

def send_message():
    msg = entry.get()
    if msg:
        s.send(msg.encode("utf-8"))
        listbox.insert(END, "Client: " + msg)
        entry.delete(0, END)

def receive_message():
    try:
        msg = s.recv(1024).decode("utf-8")
        listbox.insert(END, "Server: " + msg)
    except:
        listbox.insert(END, "Server disconnected")

# -------- Tkinter GUI --------
root = Tk()
root.title("Client")

listbox = Listbox(root, width=50)
listbox.pack(pady=10)

entry = Entry(root, width=40)
entry.pack(pady=5)

Button(root, text="Connect", command=connect_server).pack()
Button(root, text="Send", command=send_message).pack()
Button(root, text="Receive", command=receive_message).pack()

s = None
root.mainloop()

