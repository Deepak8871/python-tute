
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

HOST_NAME = "127.0.0.1"


PORT = 9090

s.bind((HOST_NAME , PORT))

s.listen(4)

print("Waiting for connection...")
client, address = s.accept()
print("Connected from", address)

while True:
    message = input("Server:")
    if message.lower() == "exit":
        break
    client.send(message.encode("utf-8"))

    message = client.recv(1024)
    if not message:
        break
    print("Client:",message.decode("utf-8"))

client.close()
s.close()

