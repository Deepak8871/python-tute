import socket
import threading
from tkinter import *

def start_server():
    global client
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    HOST = "127.0.0.1"
    PORT = 9090

    server.bind((HOST, PORT))
    server.listen(1)

    root.after(0, lambda: listbox.insert(END, "Waiting for client..."))
    client, addr = server.accept()
    root.after(0, lambda: listbox.insert(END, f"Connected to {addr}"))

def send_message():
    if client:
        msg = entry.get()
        client.send(msg.encode("utf-8"))
        listbox.insert(END, "Server: " + msg)
        entry.delete(0, END)

def receive_message():
    if client:
        try:
            msg = client.recv(1024).decode("utf-8")
            listbox.insert(END, "Client: " + msg)
        except:
            listbox.insert(END, "Client disconnected")

# -------- Tkinter GUI --------
root = Tk()
root.title("Server")

listbox = Listbox(root, width=50)
listbox.pack(pady=10)

entry = Entry(root, width=40)
entry.pack(pady=5)

Button(root, text="Send", command=send_message).pack()
Button(root, text="Receive", command=receive_message).pack()

client = None

threading.Thread(target=start_server, daemon=True).start()

root.mainloop()
