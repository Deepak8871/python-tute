import socket

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

HOST_NAME = socket.gethostbyname(socket.gethostname())  # OR '127.0.0.1'
PORT = 8080

client.connect((HOST_NAME, PORT))

#msg = s.recv(100)

""" 
while True:
    message = s.recv(50)
    print ("server:"+message.decode("utf-8"))
    message_to_send = input("client: ")
    s.send(message_to_send.encode("utf-8"))
"""
while True:
    data = client.recv(1024)
    if not data:
        print("Server disconnected")
        break

    print("Server:", data.decode("utf-8"))

    message = input("Client: ")
    if message.lower() == "exit":
        break

    client.send(message.encode("utf-8"))

client.close()
