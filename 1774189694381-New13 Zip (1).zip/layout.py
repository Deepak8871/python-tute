import socket
from tkinter import *


def send(listbox,entry):
    message = entry.get()
    listbox.insert(END,message)
    entry.delete(0,END)
    client.send(message.encode("utf-8"))

def recieve(listbox):
    message_from_client = client.recv(1024)
    listbox.insert(END,message_from_client.decode("utf-8"))

root = Tk()
entry = Entry(root)
entry.pack(side=BOTTOM)

listbox = Listbox(root)
listbox.pack()

button = Button(root,text ="send",command = lambda : send(listbox,entry))
button.pack(side=BOTTOM)
rbutton = Button(root,text ="Recieve",command = lambda :recieve(listbox,entry))
rbutton.pack(side=BOTTOM)


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

HOST_NAME = "127.0.0.1"


PORT = 9090

s.bind((HOST_NAME , PORT))

s.listen(4)

s.close()


root.mainloop()
