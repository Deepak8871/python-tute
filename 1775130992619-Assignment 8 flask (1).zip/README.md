# assignment 8 - flask registration form

## what this does

a flask web app with a registration form that saves user data to a database

## how to run

install requirements
```
pip install flask flask-wtf flask-sqlalchemy email-validator
```

run the app
```
python app.py
```

then open http://127.0.0.1:5000 in browser

## what i built

**app.py** - main flask file with everything in it
- RegisterForm class using FlaskForm with 4 fields: name, email, password, confirm_password
- User model using SQLAlchemy with id, name, email, password columns
- register route handles GET and POST. on GET shows the form, on POST validates and saves to db
- confirm route shows success page after registration

**templates/register.html** - the registration form using WTF form rendering
**templates/confirm.html** - success page after form submission

## problems i faced

- forgot SECRET_KEY at first, flask-wtf needs it for CSRF token, was getting RuntimeError
- Email() validator requires email-validator package to be installed separately
- passwords not matching was not giving error, had to add EqualTo('password') validator to confirm_password field
- db.create_all() has to run inside app.app_context() otherwise it gives error outside application context
