# web scraping assignment 6

this code scrapes amazon product page and checks if price is under target

## how to run

first install libraries
```
pip install requests beautifulsoup4 lxml
```

then run
```
python web_6_fixed.py
```

## what it does

- opens amazon url
- finds product name using productTitle id
- finds price using a-offscreen class
- removes rupee sign and commas to get number
- compares with target price and prints result

## output i got

```
Product: Samsung Galaxy S21 FE 5G (Lavender, 128GB)
Current price: 28999
Your target: 50000
price is good, buy now
```

## problems i faced

at first i was using priceblock_ourprice id to get price but it wasnt working, amazon changed their html i think. then i found a-offscreen class works. also forgot to remove commas from price string so int() was giving error, fixed that with replace(",", "")

## requirements

- requests
- beautifulsoup4
- lxml
