import requests
from bs4 import BeautifulSoup
import re

class PriceTracer:
    def __init__(self, url, target_price):
        self.url = url
        self.target_price = target_price
        self.headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"}

    def fetch_page(self):
        res = requests.get(self.url, headers=self.headers)
        self.soup = BeautifulSoup(res.text, "lxml")

    def get_title(self):
        t = self.soup.find("span", {"id": "productTitle"})
        if t:
            return t.text.strip()
        return "not found"

    def get_price(self):
        p = self.soup.find("span", {"class": "a-offscreen"})
        if p:
            return p.text.strip()
        return "not found"

    def check_price(self):
        price_text = self.get_price()
        # remove rupee symbol and commas to get number
        nums = re.findall(r"[\d]+", price_text.replace(",", ""))
        if not nums:
            print("could not read price")
            return
        price = int(nums[0])
        print("Product:", self.get_title())
        print("Current price:", price)
        print("Your target:", self.target_price)
        if price <= self.target_price:
            print("price is good, buy now")
        else:
            print("price is still high")


url = "https://www.amazon.in/Samsung-Galaxy-Lavender-128GB-Storage/dp/B09P7G25XY/"
t = PriceTracer(url, 50000)
t.fetch_page()
t.check_price()
