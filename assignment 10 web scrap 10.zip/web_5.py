import requests
from bs4 import BeautifulSoup
import csv

def Extract(url):
    response = requests.get(url=url).content
    soup = BeautifulSoup(response, 'lxml')
    tag = soup.find('div' ,{"id":"content"})
    h=tag.find_all("homepage")
    contents =[span.text for span in h]


    with open("wiki.csv1" , "w") as csv_file:
        csv_writer = csv.writer(csv_file)
        csv_writer.writerow(contents)

#Extract(url="https://en.wikipedia.org/wiki/Main_Page")

Extract(url="https://www.britannica.com/")
