from itertools import product

import requests
from bs4 import BeautifulSoup

class PriceTracer:
    def __init__(self,url):
        self.url = url
        self.user_agent ={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36"}
        self.response = requests.get(self.url,headers=self.user_agent).text
        self.soup = BeautifulSoup(self.response,"lxml")

    def product_title(self):
        title  =self.soup.find("span" ,{"id":"productTitle"})
        if title is not None:
            return title.text.strip()
        else:
            return "Tag not found"

    def product_price(self):
        price = self.soup.find("span", {"id":"priceblock_ourprice"})
        if price is not None:
            return price.text.strip()
        else:
            return "Tag not found"




#device = PriceTracer(url="https://www.amazon.in/iPhone-Pro-Max-512-Promotion/dp/B0FQG8XCJ1/ref=s9_acsd_al_ot_c2_x_0_t?_encoding=UTF8&pf_rd_m=A21TJRUUN4KGV&pf_rd_s=merchandised-search-12&pf_rd_r=B4KDB70JSKF3YGYZC1PQ&pf_rd_p=99dc6d47-86a4-4bc9-ab9e-0fd6c24a3820&pf_rd_t=&pf_rd_i=78382736031&th=1")

#print(device.product_title())
#print(device.product_price())

samsung = PriceTracer(url="https://www.amazon.in/Samsung-Galaxy-Lavender-128GB-Storage/dp/B09P7G25XY/ref=sr_1_2?crid=Z19HIU1O6E6A&dib=eyJ2IjoiMSJ9.3r8dXlg0ANox8Onv6zmPHuO4vjUv629KQ3_Gin9HlddVH0cjdVnaRSBmr1LK4g4Vbjztl3ezsjDfnYBpTyhtnqJ6aQZJ_sAn_ZyV4GJZuDur8zk4sTmu9NsjyZ73Db3XpvIjgP_vGGBkG2W7zwAGayff7v_duR2IejW21mDmvtv3KTaeHzpIjzyY97a9WlRWSVaWraK58OHK12yB0yUMARj6Hl7zET5fHZ_6ZtMOZRU.XuhbsamgJUp8mSTFlY0S3kVghT8ceU1ix_LFWdj-Ur4&dib_tag=se&keywords=samsung%2Bgalaxy%2Bs21&qid=1769030476&sprefix=samsunf%2Bglaxy%2Bs21%2Caps%2C396&sr=8-2&th=1")
print(samsung.product_title())
print(samsung.product_price())