from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated
from users.models import UserProfile
from users.serializers import UserProfileSerializer
from users.permissions import IsOwnerOrReadOnly


class UserProfileView(ModelViewSet):
    permission_classes = [IsAuthenticated, IsOwnerOrReadOnly]
    serializer_class = UserProfileSerializer

    def get_queryset(self):
        return UserProfile.objects.all()
