from django.contrib import admin
from django.urls import path, include
from rest_framework import routers
from users.views import UserProfileView

router = routers.SimpleRouter()
router.register('users', UserProfileView, basename='users')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include(router.urls)),
    path('api-auth/', include('rest_framework.urls')),
]
