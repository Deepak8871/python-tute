# assignment 9 - django rest api (user profiles)

## project structure

```
myapi/
    manage.py
    myapi/
        settings.py
        urls.py
        wsgi.py
        asgi.py
    users/
        models.py
        serializers.py
        views.py
        permissions.py
        migrations/
            0001_initial.py
```

## how to run

install requirements
```
pip install django djangorestframework
```

run migrations and start server
```
cd myapi
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

## api endpoints

| url | method | what it does |
|-----|--------|-------------|
| /api/users/ | GET | list all user profiles |
| /api/users/{id}/ | GET | get one user profile |
| /api/users/{id}/ | PUT/PATCH | update profile (only owner) |
| /api/users/{id}/ | DELETE | delete profile (only owner) |
| /api-auth/ | - | login/logout for browsable api |

## what i built

**models.py** - UserProfile model linked to django's built in User with OneToOneField, has bio, location, date_of_birth fields

**serializers.py** - UserProfileSerializer, username and email pulled from related User using source= parameter, both are read only

**views.py** - UserProfileView using ModelViewSet, requires login to access any endpoint

**permissions.py** - IsOwnerOrReadOnly so anyone can view profiles but only the owner can edit or delete their own

## problems i faced

- at first i extended AbstractUser to make a custom user model but that requires changing AUTH_USER_MODEL in settings and redo all migrations, it was getting complicated. switched to UserProfile with OneToOneField which is simpler
- username and email are on the User model not UserProfile so had to use source='user.username' in serializer to include them in the response
- delete was working for any logged in user, realised i forgot to add IsOwnerOrReadOnly to permission_classes
